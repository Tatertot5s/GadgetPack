var fs = require('fs');

var itemJSON = {
    "parent": "minecraft:item/template_spawn_egg_model",
    "textures": {
        "texture": ""
    }
};

var texture = ["goat_spawn_egg", "glow_squid_spawn_egg", "axolotl_spawn_egg"];

for (var i = 0; i < texture.length; i++) {
	var name = texture[i];
	var itemLayer = "item/" + texture[i]
	
	itemJSON.textures.texture = itemLayer
	fs.writeFileSync("item/" + name + ".json", JSON.stringify(itemJSON));
}
